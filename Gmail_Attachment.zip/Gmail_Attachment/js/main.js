const initAttachmentButton = () => {
  const emailContent = document.querySelector('.hq.gt');
  if(emailContent){
      var attachmentButton = document.createElement("button");
      attachmentButton.textContent = "Move Attachment To Top";
      attachmentButton.classList.add('attachment_btn');
      let moved = false;
      attachmentButton.addEventListener('click', function(event) {
          //const parent = attachmentButton.parentNode;
          if (!moved) {
              // parent.insertBefore(emailContent, attachmentButton.nextSibling);
              document.querySelector('.btm').appendChild(emailContent);
              attachmentButton.textContent = "Move Attachment To Bottom";
              moved = true;
          } 
          else {
              var email = document.querySelector('.hq.gt');
              var body = document.querySelector('.ii.gt');
              body.appendChild(email);
              attachmentButton.textContent = "Move Attachment To Top";
              moved = false;
          }
      });
  }
  else{
    return;
  }
  return attachmentButton;
};
const initExtraStyling = (elem) => {
  var emailContent = document.querySelector('.hq.gt');
  if(emailContent){ 
  const dvelem3 = document.createElement("div");
  dvelem3.classList.add('.gE.iv.gt');
  dvelem3.appendChild(initAttachmentButton());
  elem.appendChild(dvelem3);
  }
  
};
  
const initAttachmentTemplate = () => {
  document.querySelector('body').addEventListener('click', function(event) {
      var target = event.target;
      while (target.parentNode && target.parentNode !== document.querySelector('.h7')){
        target = target.parentNode;    
      } 
      if (!target.querySelector('.attachment_btn')) {
       
          var elem = document.querySelector('.btm');
          initExtraStyling(elem);
      }

  });

};
  
const init = async () => {
  initAttachmentTemplate();
};
  
export const main = async () => {
  await init();
};
